import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class EditUnitFrame extends JFrame {

	private JPanel contentPane;
	private JTextField unitRouteField;
	private JTextField rentCostField;
	
    private String dbsURL = "jdbc:mysql://localhost/finals";
    private String userName = "root";
    private String password = "Iammartin..64Mykee20180014301";
    private Connection conn = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
	/**
	 * Create the frame.
	 */
	public EditUnitFrame(String newUnitNo) {
		setVisible(true);
		setTitle("AVMS: Edit unit");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 514, 222);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(15, 16, 464, 134);
		contentPane.add(panel);
		
		JLabel label_1 = new JLabel("Unit route:");
		label_1.setBounds(15, 16, 77, 20);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Rent cost:");
		label_2.setBounds(21, 52, 71, 20);
		panel.add(label_2);
		
		unitRouteField = new JTextField();
		unitRouteField.setColumns(10);
		unitRouteField.setBounds(107, 13, 343, 26);
		panel.add(unitRouteField);
		
		rentCostField = new JTextField();
		rentCostField.setColumns(10);
		rentCostField.setBounds(107, 49, 343, 26);
		panel.add(rentCostField);
		
		JButton btnSaveChanges = new JButton("Save changes");
		btnSaveChanges.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String editFromDatabase = "update units set unitRoute=?, rentCost=? where unitNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(editFromDatabase);
		            pst.setString(1, unitRouteField.getText());
		            pst.setString(2, rentCostField.getText());
		            pst.setString(3, newUnitNo); //(index, String) of "(?,?,?)"
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Edit successful");
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
		        dispose();
			}
		});
		btnSaveChanges.setBounds(323, 89, 127, 29);
		panel.add(btnSaveChanges);
	}

}
