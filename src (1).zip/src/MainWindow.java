import java.awt.CardLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;
import java.awt.Color;

public class MainWindow extends JFrame {

	private JPanel contentPane;
	private JTable unitsTable;
	private JTextField fNameField;
	private JTextField mNameField;
	private JTextField lNameField;
	private JTextField addressField;
	private JTextField contactNumberField;
	private JTextField unitNumberField;
	private JTextField unitRouteField;
	private JTextField rentCostField;
	private JTextField unitHistoryField;
	private JTable driversTable;
	private JTextField driverIDField;
	private JTable reportsTable;
	private JTextField viewReportDateField;
	private JTextField fuelCostField;
	private JTextField newReportDriverNameField;
	private JTextField newReportRentCostField;
	private JTable newReportTable;
	
    private String dbsURL = "jdbc:mysql://localhost/finals";
    private String userName = "root";
    private String password = "Iammartin..64Mykee20180014301";
    private Connection conn = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private JTextField bDateField;
    private JTextField fuelConsumedField;
    private JTextField methodField;
    private JTextField reportDateField;
    
	/**
	 * Create the frame.
	 */
	public MainWindow() {
		setResizable(false);
		setTitle("AVMS: Main window");
		this.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 872, 457);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel parentPanel = new JPanel();
		parentPanel.setBounds(247, 70, 588, 301);
		contentPane.add(parentPanel);
		parentPanel.setLayout(new CardLayout(0, 0));
		
		JPanel defaultPanel = new JPanel();
		parentPanel.add(defaultPanel, "name_105863542857100");
		
		JPanel newReportPanel = new JPanel();
		parentPanel.add(newReportPanel, "name_97562938576247");
		newReportPanel.setLayout(null);
		
		JLabel lblNewLabel_7 = new JLabel("Fuel cost per liter:");
		lblNewLabel_7.setBounds(15, 259, 128, 20);
		newReportPanel.add(lblNewLabel_7);
		
		JLabel lblDriverId = new JLabel("Driver ID:");
		lblDriverId.setBounds(15, 16, 71, 20);
		newReportPanel.add(lblDriverId);
		
		JLabel lblNewLabel_8 = new JLabel("UnitNo:");
		lblNewLabel_8.setBounds(15, 52, 55, 20);
		newReportPanel.add(lblNewLabel_8);
		
		newReportDriverNameField = new JTextField();
		newReportDriverNameField.setEditable(false);
		newReportDriverNameField.setBounds(284, 13, 93, 26);
		newReportPanel.add(newReportDriverNameField);
		newReportDriverNameField.setColumns(10);
		
		JComboBox<String> driverIDComboBox = new JComboBox<String>();
		driverIDComboBox.setBounds(101, 13, 60, 26);
		newReportPanel.add(driverIDComboBox);
		try {
			String selectFromDataBase = "select DriverID from drivers";
            conn = DriverManager.getConnection(dbsURL, userName, password);
            pst = conn.prepareStatement(selectFromDataBase);
            rs = pst.executeQuery();
            
            while(rs.next()) {
            	driverIDComboBox.addItem(rs.getString("DriverID"));
            }
			
		}catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
		
		//automatically changes the driverNameField based on the comboBox choice
		driverIDComboBox.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String selectFromDataBase = "select Fname from drivers where DriverID = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(selectFromDataBase);
		            pst.setString(1, (String) driverIDComboBox.getSelectedItem());
		            rs = pst.executeQuery();
		            
		            while(rs.next()) {
		            	newReportDriverNameField.setText(rs.getString("Fname"));
		            }
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
				
			}
			
		});
		
		newReportRentCostField = new JTextField();
		newReportRentCostField.setEditable(false);
		newReportRentCostField.setBounds(284, 49, 93, 26);
		newReportPanel.add(newReportRentCostField);
		newReportRentCostField.setColumns(10);
		
		JComboBox<String> unitNoComboBox = new JComboBox<String>();
		unitNoComboBox.setBounds(85, 49, 76, 26);
		newReportPanel.add(unitNoComboBox);
		try {
			String selectFromDataBase = "select unitNo from units";
            conn = DriverManager.getConnection(dbsURL, userName, password);
            pst = conn.prepareStatement(selectFromDataBase);
            rs = pst.executeQuery();
            
            while(rs.next()) {
            	unitNoComboBox.addItem(rs.getString("unitNo"));
            }
			
		}catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
		
		//automatically changes the rentCostField based on the comboBox choice
		unitNoComboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String selectFromDataBase = "select rentCost from units where unitNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(selectFromDataBase);
		            pst.setString(1, (String) unitNoComboBox.getSelectedItem());
		            rs = pst.executeQuery();
		            
		            while(rs.next()) {
		            	newReportRentCostField.setText(rs.getString("rentCost"));
		            }
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }			
			}

		});
		
		JLabel lblDriverName = new JLabel("Driver name:");
		lblDriverName.setBounds(176, 16, 93, 20);
		newReportPanel.add(lblDriverName);
		
		JLabel lblUnitCost = new JLabel("Rent cost:");
		lblUnitCost.setBounds(195, 52, 74, 20);
		newReportPanel.add(lblUnitCost);
		
		reportDateField = new JTextField();
		reportDateField.setText("YYYY-MM-DD");
		reportDateField.setBounds(307, 256, 106, 26);
		newReportPanel.add(reportDateField);
		reportDateField.setColumns(10);
		
		fuelCostField = new JTextField();
		fuelCostField.setBounds(158, 256, 74, 26);
		newReportPanel.add(fuelCostField);
		fuelCostField.setColumns(10);
		
		fuelConsumedField = new JTextField();
		fuelConsumedField.setBounds(528, 13, 45, 26);
		newReportPanel.add(fuelConsumedField);
		fuelConsumedField.setColumns(10);
		
		methodField = new JTextField();
		methodField.setBounds(467, 49, 106, 26);
		newReportPanel.add(methodField);
		methodField.setColumns(10);
		
		JButton newReportAddButton = new JButton("Add");
		newReportAddButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String addToDatabase = " insert into reports"
		                    +"(ReportDate, FuelCost, FuelConsumed, DriverID_Report, UnitNo_Report, PaymentMethod)" //tables 
		                    +"values (?,?,?,?,?,?);"; //values
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(addToDatabase);
		            pst.setString(1, reportDateField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, fuelCostField.getText());
		            pst.setString(3, fuelConsumedField.getText());
		            pst.setString(4, (String) driverIDComboBox.getSelectedItem());
		            pst.setString(5, (String) unitNoComboBox.getSelectedItem());
		            pst.setString(6, methodField.getText());
		            pst.executeUpdate();
		            showSpecificReportsTable(reportDateField.getText());
		            JOptionPane.showMessageDialog(null, "Add successful");
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
				
			}
		});
		newReportAddButton.setBounds(480, 124, 93, 29);
		newReportPanel.add(newReportAddButton);
		
		JButton newReportRemoveButton = new JButton("Remove");
		newReportRemoveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from reports where UnitNo_Report=? and DriverID_Report=?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, (String) unitNoComboBox.getSelectedItem());
		            pst.setString(2, (String) driverIDComboBox.getSelectedItem());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showReportsTable();
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
				
			}
		});
		newReportRemoveButton.setBounds(480, 169, 93, 29);
		newReportPanel.add(newReportRemoveButton);
		
		JButton newReportFinishButton = new JButton("Finish");
		newReportFinishButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Heading back to homepage");
				parentPanel.removeAll();
				parentPanel.add(defaultPanel);
				parentPanel.repaint();
				parentPanel.revalidate();
			}
		});
		newReportFinishButton.setBounds(480, 214, 93, 29);
		newReportPanel.add(newReportFinishButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(15, 88, 450, 155);
		newReportPanel.add(scrollPane);
		
		newReportTable = new JTable();
		scrollPane.setViewportView(newReportTable);
		
		JLabel lblFuelConsumed = new JLabel("Fuel Consumed:");
		lblFuelConsumed.setBounds(392, 16, 121, 20);
		newReportPanel.add(lblFuelConsumed);
		
		JLabel lblPaymentMethod = new JLabel("Method:");
		lblPaymentMethod.setBounds(392, 52, 60, 20);
		newReportPanel.add(lblPaymentMethod);
		
		JLabel lblNewLabel = new JLabel("Date:");
		lblNewLabel.setBounds(247, 259, 45, 20);
		newReportPanel.add(lblNewLabel);
		
		
		JPanel viewReportsPanel = new JPanel();
		parentPanel.add(viewReportsPanel, "name_97594759315868");
		viewReportsPanel.setLayout(null);
		
		JScrollPane viewReportsScrollPane = new JScrollPane();
		viewReportsScrollPane.setBounds(0, 0, 588, 240);
		viewReportsPanel.add(viewReportsScrollPane);
		
		reportsTable = new JTable();
		viewReportsScrollPane.setViewportView(reportsTable);
		
		viewReportDateField = new JTextField();
		viewReportDateField.setBounds(124, 257, 146, 26);
		viewReportsPanel.add(viewReportDateField);
		viewReportDateField.setColumns(10);
		
		JButton viewReportViewButton = new JButton("View report");
		viewReportViewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showReportsTable(viewReportDateField.getText());
			}
		});
		viewReportViewButton.setBounds(458, 256, 115, 29);
		viewReportsPanel.add(viewReportViewButton);
		
		JLabel lblReportDate = new JLabel("Report date:");
		lblReportDate.setBounds(15, 260, 94, 20);
		viewReportsPanel.add(lblReportDate);
		
		JPanel newDriverPanel = new JPanel();
		parentPanel.add(newDriverPanel, "name_97619456389388");
		newDriverPanel.setLayout(null);
		
		JPanel viewDriversPanel = new JPanel();
		parentPanel.add(viewDriversPanel, "name_97652286447332");
		viewDriversPanel.setLayout(null);
		
		JScrollPane viewDriversScrollPane = new JScrollPane();
		viewDriversScrollPane.setBounds(0, 1, 588, 239);
		viewDriversPanel.add(viewDriversScrollPane);
		
		driversTable = new JTable();
		viewDriversScrollPane.setViewportView(driversTable);
		
		JButton driverHistoryButton = new JButton("Driver history");
		driverHistoryButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new DriverHistoryFrame();
			}
		});
		driverHistoryButton.setBounds(444, 256, 129, 29);
		viewDriversPanel.add(driverHistoryButton);
		
		driverIDField = new JTextField();
		driverIDField.setBounds(101, 257, 80, 26);
		viewDriversPanel.add(driverIDField);
		driverIDField.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Driver ID:");
		lblNewLabel_5.setBounds(15, 260, 71, 20);
		viewDriversPanel.add(lblNewLabel_5);
		
		JButton btnRemove_1 = new JButton("Remove");
		btnRemove_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from drivers where DriverID = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, driverIDField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showDriversTable();
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		btnRemove_1.setBounds(340, 256, 89, 29);
		viewDriversPanel.add(btnRemove_1);
		
		JButton btnEdit_1 = new JButton("Edit");
		btnEdit_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String newDriverID = driverIDField.getText();
				new EditDriverFrame(newDriverID);
			}
		});
		btnEdit_1.setBounds(254, 256, 71, 29);
		viewDriversPanel.add(btnEdit_1);
		
		JPanel newUnitPanel = new JPanel();
		parentPanel.add(newUnitPanel, "name_97671118507965");
		newUnitPanel.setLayout(null);
		
		JPanel viewUnitsPanel = new JPanel();
		parentPanel.add(viewUnitsPanel, "name_97701159429444");
		viewUnitsPanel.setLayout(null);
		
		JButton newReportButton = new JButton("Create new report");
		newReportButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				parentPanel.removeAll();
				parentPanel.add(newReportPanel);
				parentPanel.repaint();
				parentPanel.revalidate();
			}
		});
		newReportButton.setBounds(15, 70, 217, 29);
		contentPane.add(newReportButton);
		
		JButton viewReportsButton = new JButton("View reports");
		viewReportsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				parentPanel.removeAll();
				parentPanel.add(viewReportsPanel);
				parentPanel.repaint();
				parentPanel.revalidate();
				showReportsTable();
			}
		});
		viewReportsButton.setBounds(15, 205, 217, 29);
		contentPane.add(viewReportsButton);
		
		JButton newDriverButton = new JButton("Register new driver");
		newDriverButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				parentPanel.removeAll();
				parentPanel.add(newDriverPanel);
				parentPanel.repaint();
				parentPanel.revalidate();
			}
		});
		newDriverButton.setBounds(15, 115, 217, 29);
		contentPane.add(newDriverButton);
		
		JButton viewDriversButton = new JButton("View registered drivers");
		viewDriversButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				parentPanel.removeAll();
				parentPanel.add(viewDriversPanel);
				parentPanel.repaint();
				parentPanel.revalidate();
				showDriversTable();
			}
		});
		viewDriversButton.setBounds(15, 250, 217, 29);
		contentPane.add(viewDriversButton);
		
		JButton newUnitButton = new JButton("Register new unit");
		newUnitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				parentPanel.removeAll();
				parentPanel.add(newUnitPanel);
				parentPanel.repaint();
				parentPanel.revalidate();
			}
		});
		newUnitButton.setBounds(15, 160, 217, 29);
		contentPane.add(newUnitButton);
		
		JButton viewUnitsButton = new JButton("View registered units");
		viewUnitsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				parentPanel.removeAll();
				parentPanel.add(viewUnitsPanel);
				parentPanel.repaint();
				parentPanel.revalidate();
				showUnitsTable();
			}
		});
		viewUnitsButton.setBounds(15, 295, 217, 29);
		contentPane.add(viewUnitsButton);
		
		JLabel fNameLabel = new JLabel("First name:");
		fNameLabel.setBounds(64, 16, 80, 20);
		newDriverPanel.add(fNameLabel);
		
		JLabel mNameLabel = new JLabel("Middle name:");
		mNameLabel.setBounds(48, 52, 96, 20);
		newDriverPanel.add(mNameLabel);
		
		JLabel lNameLabel = new JLabel("Last name:");
		lNameLabel.setBounds(66, 88, 78, 20);
		newDriverPanel.add(lNameLabel);
		
		JLabel bDateLabel = new JLabel("Birthdate:");
		bDateLabel.setBounds(70, 124, 74, 20);
		newDriverPanel.add(bDateLabel);
		
		JLabel addressLabel = new JLabel("Address:");
		addressLabel.setBounds(76, 160, 68, 20);
		newDriverPanel.add(addressLabel);
		
		JLabel contactNumberLabel = new JLabel("Contact number:");
		contactNumberLabel.setBounds(25, 196, 119, 20);
		newDriverPanel.add(contactNumberLabel);
		
		fNameField = new JTextField();
		fNameField.setBounds(157, 13, 343, 26);
		newDriverPanel.add(fNameField);
		fNameField.setColumns(10);
		
		mNameField = new JTextField();
		mNameField.setBounds(157, 49, 343, 26);
		newDriverPanel.add(mNameField);
		mNameField.setColumns(10);
		
		lNameField = new JTextField();
		lNameField.setBounds(157, 85, 343, 26);
		newDriverPanel.add(lNameField);
		lNameField.setColumns(10);
		
		addressField = new JTextField();
		addressField.setBounds(157, 157, 343, 26);
		newDriverPanel.add(addressField);
		addressField.setColumns(10);
		
		bDateField = new JTextField();
		bDateField.setText("YYYY-MM-DD");
		bDateField.setBounds(157, 121, 343, 26);
		newDriverPanel.add(bDateField);
		bDateField.setColumns(10);
		
		contactNumberField = new JTextField();
		contactNumberField.setBounds(157, 193, 343, 26);
		newDriverPanel.add(contactNumberField);
		contactNumberField.setColumns(10);
		
		JButton driverRegisterButton = new JButton("Register");
		driverRegisterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		        try{
		            String insertToDatabase = " insert into drivers"
		                    +"(Fname, Mname, Lname, Bdate, Address, ContactNumber)" //tables 
		                    +"values (?,?,?,?,?,?);";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(insertToDatabase);
		            pst.setString(1, fNameField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, mNameField.getText());
		            pst.setString(3, lNameField.getText());
		            pst.setString(4, bDateField.getText());
		            pst.setString(5, addressField.getText());
		            pst.setString(6, contactNumberField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Unit registered");
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		driverRegisterButton.setBounds(458, 256, 115, 29);
		newDriverPanel.add(driverRegisterButton);
		
		
		JLabel unitNumLabel = new JLabel("Unit number:");
		unitNumLabel.setBounds(38, 16, 95, 20);
		newUnitPanel.add(unitNumLabel);
		
		JLabel unitRouteLabel = new JLabel("Unit route:");
		unitRouteLabel.setBounds(48, 58, 85, 20);
		newUnitPanel.add(unitRouteLabel);
		
		JLabel rentCostLabel = new JLabel("Rent cost:");
		rentCostLabel.setBounds(58, 94, 71, 20);
		newUnitPanel.add(rentCostLabel);
		
		unitNumberField = new JTextField();
		unitNumberField.setBounds(148, 13, 343, 26);
		newUnitPanel.add(unitNumberField);
		unitNumberField.setColumns(10);
		
		unitRouteField = new JTextField();
		unitRouteField.setBounds(148, 52, 343, 26);
		newUnitPanel.add(unitRouteField);
		unitRouteField.setColumns(10);
		
		rentCostField = new JTextField();
		rentCostField.setBounds(148, 91, 343, 26);
		newUnitPanel.add(rentCostField);
		rentCostField.setColumns(10);
		
		JButton unitRegisterButton = new JButton("Register");
		unitRegisterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String insertToDatabase = " insert into units"
		                    +"(unitNo, unitRoute, rentCost)" //tables 
		                    +"values (?,?,?);"; //values
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(insertToDatabase);
		            pst.setString(1, unitNumberField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, unitRouteField.getText());
		            pst.setString(3, rentCostField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Unit registered");
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		unitRegisterButton.setBounds(458, 256, 115, 29);
		newUnitPanel.add(unitRegisterButton);
		
		JScrollPane viewUnitScrollPane = new JScrollPane();
		viewUnitScrollPane.setBounds(0, 0, 588, 240);
		viewUnitsPanel.add(viewUnitScrollPane);
		
		unitsTable = new JTable();
		viewUnitScrollPane.setViewportView(unitsTable);
		
		JButton unitHistoryButton = new JButton("Unit history");
		unitHistoryButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new UnitHistoryFrame();
			}
		});
		unitHistoryButton.setBounds(458, 256, 115, 29);
		viewUnitsPanel.add(unitHistoryButton);
		
		unitHistoryField = new JTextField();
		unitHistoryField.setBounds(125, 257, 80, 26);
		viewUnitsPanel.add(unitHistoryField);
		unitHistoryField.setColumns(10);
		
		JLabel unitHistoryLabel = new JLabel("Unit number:");
		unitHistoryLabel.setBounds(15, 260, 95, 20);
		viewUnitsPanel.add(unitHistoryLabel);
		
		JButton removeUnitButton = new JButton("Remove");
		removeUnitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from units where unitNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, unitHistoryField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showUnitsTable();
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
				String findFromDatabase = "";
			}
		});
		removeUnitButton.setBounds(356, 256, 89, 29);
		viewUnitsPanel.add(removeUnitButton);
		
		JButton editUnitButton = new JButton("Edit");
		editUnitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newUnitNo = unitHistoryField.getText();
				new EditUnitFrame(newUnitNo);
			}
		});
		editUnitButton.setBounds(282, 256, 59, 29);
		viewUnitsPanel.add(editUnitButton);
		
	}
	
	
	public void showDriversTable() {
        try{
            conn = DriverManager.getConnection(dbsURL, userName, password);
            String select = "select * from drivers";
            pst = conn.prepareStatement(select);
            rs = pst.executeQuery();
            driversTable.setModel(DbUtils.resultSetToTableModel(rs)); //this was supposed to show error I configured its problem severity from 'error' to 'warning'
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
	}
	
	public void showUnitsTable() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from units";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        unitsTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void showReportsTable() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from reports";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        reportsTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void showReportsTable(String specificDate) {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from reports where ReportDate = ?";
			pst = conn.prepareStatement(select);
			pst.setString(1, specificDate);
			rs = pst.executeQuery();
	        reportsTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void showSpecificReportsTable(String specificDate) {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from reports where ReportDate = ?";
			pst = conn.prepareStatement(select);
			pst.setString(1, specificDate);
			rs = pst.executeQuery();
	        newReportTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void showReportList() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from units";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        reportsTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
}
