import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

public class LoginFrame extends JFrame {

	private JPanel contentPane;
	private JTextField usernameField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setBackground(Color.GRAY);
		setTitle("AVMS: Login");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 405, 216);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel usernameLabel = new JLabel("Username:");
		usernameLabel.setBounds(25, 55, 82, 20);
		contentPane.add(usernameLabel);
		
		JLabel passwordLabel = new JLabel("Password:");
		passwordLabel.setBounds(25, 91, 82, 20);
		contentPane.add(passwordLabel);
		
		usernameField = new JTextField();
		usernameField.setBounds(122, 52, 241, 26);
		contentPane.add(usernameField);
		usernameField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(122, 88, 241, 26);
		contentPane.add(passwordField);
		
		JLabel statsLabel = new JLabel("Please login to continue");
		statsLabel.setBounds(132, 16, 183, 20);
		contentPane.add(statsLabel);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String usernameText = usernameField.getText();
				String passwordText = passwordField.getText();
				
				String dbURL = "jdbc:mysql://localhost/finals";
				String dbUserName = "root";
				String dbPassword = "Iammartin..64Mykee20180014301";
				
				Connection conn = null;
				PreparedStatement pst = null;
				ResultSet rs1 = null;
				ResultSet rs2 = null;
				
				try {
					conn = DriverManager.getConnection(dbURL, dbUserName, dbPassword);
					
					String selectPasswordStatement = "SELECT userPassword FROM user_account WHERE userName = " + "?";
					pst = conn.prepareStatement(selectPasswordStatement);
					pst.setString(1, usernameText);
					rs1 = pst.executeQuery();
					
					String selectUserNameStatement = "SELECT userName FROM user_account WHERE userPassword = " + "?";
					pst = conn.prepareStatement(selectUserNameStatement);
					pst.setString(1, passwordText);
					rs2 = pst.executeQuery();
					
					if(rs1.next() && rs2.next()) {
						String retrievedPassword = rs1.getString("userPassword");
						String retrievedUsername = rs2.getString("userName");
						
						if(retrievedPassword.trim().equals(passwordText) && retrievedUsername.trim().equals(usernameText)) {
							SwingUtilities.invokeLater(new Runnable() {
								public void run() {
									hideFrame();
									new MainWindow();
								}
							});
						}
					}else {
						statsLabel.setForeground(Color.red);
						statsLabel.setText("User Doesn't Exist");
					}
				}catch (Exception e){
					statsLabel.setForeground(Color.red);
					statsLabel.setText("Error from program. Please restart");
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		
		btnLogin.setBounds(267, 130, 96, 29);
		contentPane.add(btnLogin);
	}
	public void hideFrame() {
		this.setVisible(false);
	}
}
