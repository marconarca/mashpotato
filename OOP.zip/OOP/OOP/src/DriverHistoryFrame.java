import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class DriverHistoryFrame extends JFrame {

	private JPanel contentPane;
	private JTable documentsTable;
	private JTextField liabilityDescField;
	private JTextField liabilityDateField;
	private JTextField liabilityNoField;
	private JTextField documentDescField;
	private JTextField documentNoField;

    private String dbsURL = "jdbc:mysql://localhost/finals";
    private String userName = "root";
    private String password = "Iammartin..64Mykee20180014301";
    private Connection conn = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private JTable liabilitiesTable;
    private JTextField liabilityCostField;
    private JTextField driverIDField;
    private JTextField driverDocumentIDField;
	/**
	 * Create the frame.
	 */
	public DriverHistoryFrame() {
		setBackground(Color.GRAY);
		setVisible(true);
		setTitle("AVMS: Driver history");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 724, 429);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(20, 19, 663, 332);
		contentPane.add(tabbedPane);
		
		JPanel liabilitiesPanel = new JPanel();
		tabbedPane.addTab("Liabilities", null, liabilitiesPanel, null);
		liabilitiesPanel.setLayout(null);
		
		liabilityDescField = new JTextField();
		liabilityDescField.setBounds(123, 53, 151, 26);
		liabilitiesPanel.add(liabilityDescField);
		liabilityDescField.setColumns(10);
		
		liabilityDateField = new JTextField();
		liabilityDateField.setBounds(123, 89, 151, 26);
		liabilitiesPanel.add(liabilityDateField);
		liabilityDateField.setColumns(10);
		
		liabilityNoField = new JTextField();
		liabilityNoField.setBounds(123, 213, 151, 26);
		liabilitiesPanel.add(liabilityNoField);
		liabilityNoField.setColumns(10);
		
		driverIDField = new JTextField();
		driverIDField.setBounds(123, 19, 151, 26);
		liabilitiesPanel.add(driverIDField);
		driverIDField.setColumns(10);
		
		JButton addLiabilityButton = new JButton("Add");
		addLiabilityButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String addToDatabase = " insert into liabilities"
		                    +"(LiabilityDesc, LiabilityDate, LiabilityCost, LiabilityDriverID)" //tables 
		                    +"values (?,?,?,?);"; //values
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(addToDatabase);
		            pst.setString(1, liabilityDescField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, liabilityDateField.getText());
		            pst.setString(3, liabilityCostField.getText());
		            pst.setString(4, driverIDField.getText());
		            pst.executeUpdate();
		            showLiabilitiesTable();
		            JOptionPane.showMessageDialog(null, "Liability registered");
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		addLiabilityButton.setBounds(15, 164, 61, 29);
		liabilitiesPanel.add(addLiabilityButton);
		
		JButton editLiabilityButton = new JButton("Edit");
		editLiabilityButton.setBounds(15, 255, 61, 29);
		editLiabilityButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String editFromDatabase = "update liabilities set LiabilityDesc=?, LiabilityDate=?, LiabilityCost=?, LiabilityDriverID=? where LiabilityNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(editFromDatabase);
		            pst.setString(1, liabilityDescField.getText());
		            pst.setString(2, liabilityDateField.getText());
		            pst.setString(3, liabilityCostField.getText());
		            pst.setString(4, driverIDField.getText());
		            pst.setString(5, liabilityNoField.getText());//(index, String) of "(?,?,?)"
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Edit successful");
		            showLiabilitiesTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		liabilitiesPanel.add(editLiabilityButton);
		
		JButton removeLiabilityButton = new JButton("Remove");
		removeLiabilityButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from liabilities where LiabilityNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, liabilityNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showLiabilitiesTable();
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		removeLiabilityButton.setBounds(90, 255, 89, 29);
		liabilitiesPanel.add(removeLiabilityButton);
		
		JLabel lblLiabilitydesc = new JLabel("LiabilityDesc:");
		lblLiabilitydesc.setBounds(15, 56, 93, 20);
		liabilitiesPanel.add(lblLiabilitydesc);
		
		JLabel lblLiabilitydate = new JLabel("LiabilityDate:");
		lblLiabilitydate.setBounds(15, 92, 93, 20);
		liabilitiesPanel.add(lblLiabilitydate);
		
		JLabel lblLiabilityno = new JLabel("LiabilityNo:");
		lblLiabilityno.setBounds(15, 219, 80, 20);
		liabilitiesPanel.add(lblLiabilityno);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(291, 19, 352, 224);
		liabilitiesPanel.add(scrollPane);
		
		liabilitiesTable = new JTable();
		scrollPane.setViewportView(liabilitiesTable);
		
		JLabel lblLiabilitycost = new JLabel("LiabilityCost:");
		lblLiabilitycost.setBounds(15, 128, 93, 20);
		liabilitiesPanel.add(lblLiabilitycost);
		
		liabilityCostField = new JTextField();
		liabilityCostField.setBounds(123, 125, 151, 26);
		liabilitiesPanel.add(liabilityCostField);
		liabilityCostField.setColumns(10);
		
		JLabel lblDriverid = new JLabel("DriverID:");
		lblDriverid.setBounds(15, 22, 69, 20);
		liabilitiesPanel.add(lblDriverid);
		
		JPanel documentsPanel = new JPanel();
		tabbedPane.addTab("Documents", null, documentsPanel, null);
		documentsPanel.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(289, 16, 354, 227);
		documentsPanel.add(scrollPane_2);
		
		documentsTable = new JTable();
		scrollPane_2.setViewportView(documentsTable);
		
		documentDescField = new JTextField();
		documentDescField.setBounds(141, 49, 133, 26);
		documentsPanel.add(documentDescField);
		documentDescField.setColumns(10);
		
		documentNoField = new JTextField();
		documentNoField.setBounds(152, 183, 133, 26);
		documentsPanel.add(documentNoField);
		documentNoField.setColumns(10);
		
		driverDocumentIDField = new JTextField();
		driverDocumentIDField.setBounds(141, 16, 133, 26);
		documentsPanel.add(driverDocumentIDField);
		driverDocumentIDField.setColumns(10);
		
		JButton addDocumentButton = new JButton("Add");
		addDocumentButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String addToDatabase = " insert into documents"
		                    +"(DocumentDesc, DocumentDriverID)" //tables 
		                    +"values (?,?);"; //values
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(addToDatabase);
		            pst.setString(1, documentDescField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, driverDocumentIDField.getText());
		            pst.executeUpdate();
		            showDocumentsTable();
		            JOptionPane.showMessageDialog(null, "Liability registered");
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
			
		});
		addDocumentButton.setBounds(15, 98, 61, 29);
		documentsPanel.add(addDocumentButton);
		
		JButton editDocuementButton = new JButton("Edit desc");
		editDocuementButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String editFromDatabase = "update documents set DocumentDesc=?, DocumentDriverID=? where DocumentNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(editFromDatabase);
		            pst.setString(1, documentDescField.getText());
		            pst.setString(2, driverDocumentIDField.getText());
		            pst.setString(3, documentNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Edit successful");
		            showDocumentsTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		editDocuementButton.setBounds(15, 214, 98, 29);
		documentsPanel.add(editDocuementButton);
		
		JButton removeDocumentButton = new JButton("Remove");
		removeDocumentButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from documents where DocumentNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, documentNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showDocumentsTable();
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		removeDocumentButton.setBounds(15, 255, 89, 29);
		documentsPanel.add(removeDocumentButton);
		
		JLabel lblDocumentdesc = new JLabel("DocumentDesc:");
		lblDocumentdesc.setBounds(15, 52, 111, 20);
		documentsPanel.add(lblDocumentdesc);
		
		JLabel lblDocumentno = new JLabel("DocumentNo:");
		lblDocumentno.setBounds(15, 186, 98, 20);
		documentsPanel.add(lblDocumentno);
		
		JLabel lblDriverid_1 = new JLabel("DriverID:");
		lblDriverid_1.setBounds(15, 16, 69, 20);
		documentsPanel.add(lblDriverid_1);
		
		showDocumentsTable();
		showLiabilitiesTable();
	}
	
	public void showDocumentsTable() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from documents";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        documentsTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public void showLiabilitiesTable() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from liabilities";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        liabilitiesTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
}
