import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.Color;

public class UnitHistoryFrame extends JFrame {

	private JPanel contentPane;
	private JTable damagesTable;
	private JTextField damageDescField;
	private JTextField damageDateField;
	private JTextField damageNoField;
	private JTable repairsTable;
	private JTextField repairDescField;
	private JTextField repairDateField;
	private JTextField repairNoField;
	private JTable maintenanceTable;
	private JTextField maintenanceDescField;
	private JTextField maintenanceDateField;
	private JTextField maintenanceNoField;

    private String dbsURL = "jdbc:mysql://localhost/finals";
    private String userName = "root";
    private String password = "Iammartin..64Mykee20180014301";
    private Connection conn = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private JTextField maintenanceUnitNoField;
    private JTextField repairUnitNoField;
    private JTextField damageUnitNoField;
    
	/**
	 * Create the frame.
	 */
	public UnitHistoryFrame() {
		setBackground(Color.GRAY);
		setResizable(false);
		setVisible(true);
		setTitle("AVMS: Unit history");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 712, 426);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.GRAY);
		tabbedPane.setBounds(23, 25, 662, 334);
		contentPane.add(tabbedPane);
		
		JPanel damagesPane = new JPanel();
		tabbedPane.addTab("Damages", null, damagesPane, null);
		damagesPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(288, 16, 354, 228);
		damagesPane.add(scrollPane);
		
		damagesTable = new JTable();
		scrollPane.setViewportView(damagesTable);
		
		JLabel lblNewLabel = new JLabel("DamageDesc:");
		lblNewLabel.setBounds(15, 52, 97, 20);
		damagesPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("DamageDate:");
		lblNewLabel_1.setBounds(15, 88, 97, 20);
		damagesPane.add(lblNewLabel_1);
		
		damageDescField = new JTextField();
		damageDescField.setBounds(127, 49, 146, 26);
		damagesPane.add(damageDescField);
		damageDescField.setColumns(10);
		
		damageDateField = new JTextField();
		damageDateField.setText("YYYY-MM-DD");
		damageDateField.setBounds(127, 85, 146, 26);
		damagesPane.add(damageDateField);
		damageDateField.setColumns(10);
		
		damageUnitNoField = new JTextField();
		damageUnitNoField.setBounds(127, 16, 146, 26);
		damagesPane.add(damageUnitNoField);
		damageUnitNoField.setColumns(10);
		
		JButton addDamageButton = new JButton("Add");
		addDamageButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String addToDatabase = " insert into damages"
		                    +"(DamageDesc, DamageDate, DamageUnitNo)" //tables 
		                    +"values (?,?,?);"; //values
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(addToDatabase);
		            pst.setString(1, damageDescField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, damageDateField.getText());
		            pst.setString(3, damageUnitNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Damage registered");
		            showDamagesTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		addDamageButton.setBounds(15, 124, 61, 29);
		damagesPane.add(addDamageButton);
		
		JLabel lblDamageno = new JLabel("DamageNo:");
		lblDamageno.setBounds(15, 179, 97, 20);
		damagesPane.add(lblDamageno);
		
		damageNoField = new JTextField();
		damageNoField.setBounds(127, 176, 146, 26);
		damagesPane.add(damageNoField);
		damageNoField.setColumns(10);
		
		JButton editDamageButton = new JButton("Edit");
		editDamageButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String editFromDatabase = "update damages set DamageDesc=?, DamageDate=?, DamageUnitNo=? where DamageNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(editFromDatabase);
		            pst.setString(1, damageDescField.getText());
		            pst.setString(2, damageDateField.getText());
		            pst.setString(3, damageUnitNoField.getText());
		            pst.setString(4, damageNoField.getText()); //(index, String) of "(?,?,?)"
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Edit successful");
		            showDamagesTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		editDamageButton.setBounds(15, 215, 61, 29);
		damagesPane.add(editDamageButton);
		
		JButton removeDamageButton = new JButton("Remove");
		removeDamageButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from damages where DamageNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, damageNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showDamagesTable();
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		removeDamageButton.setBounds(15, 255, 89, 29);
		damagesPane.add(removeDamageButton);
		
		JLabel lblUnitno_2 = new JLabel("UnitNo:");
		lblUnitno_2.setBounds(15, 16, 61, 20);
		damagesPane.add(lblUnitno_2);
		
		JPanel repairsPane = new JPanel();
		tabbedPane.addTab("Repairs", null, repairsPane, null);
		repairsPane.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("RepairDesc:");
		lblNewLabel_2.setBounds(15, 52, 91, 20);
		repairsPane.add(lblNewLabel_2);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(288, 16, 354, 228);
		repairsPane.add(scrollPane_1);
		
		repairsTable = new JTable();
		scrollPane_1.setViewportView(repairsTable);
		
		repairDescField = new JTextField();
		repairDescField.setBounds(121, 49, 152, 26);
		repairsPane.add(repairDescField);
		repairDescField.setColumns(10);
		
		JLabel lblRepairdate = new JLabel("RepairDate:");
		lblRepairdate.setBounds(15, 88, 83, 20);
		repairsPane.add(lblRepairdate);
		
		repairDateField = new JTextField();
		repairDateField.setText("YYYY-MM-DD");
		repairDateField.setBounds(121, 85, 152, 26);
		repairsPane.add(repairDateField);
		repairDateField.setColumns(10);
		
		repairUnitNoField = new JTextField();
		repairUnitNoField.setBounds(121, 11, 152, 26);
		repairsPane.add(repairUnitNoField);
		repairUnitNoField.setColumns(10);
		
		JButton addRepairButton = new JButton("Add");
		addRepairButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String addToDatabase = " insert into repairs"
		                    +"(RepairDesc, RepairDate, RepairUnitNo)" //tables 
		                    +"values (?,?,?);"; //values
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(addToDatabase);
		            pst.setString(1, repairDescField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, repairDateField.getText());
		            pst.setString(3, repairUnitNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Repair registered");
		            showRepairsTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		addRepairButton.setBounds(15, 124, 61, 29);
		repairsPane.add(addRepairButton);
		
		JButton editRepairButton = new JButton("Edit");
		editRepairButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String editFromDatabase = "update repairs set RepairDesc=?, RepairDate=?, RepairUnitNo=? where RepairNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(editFromDatabase);
		            pst.setString(1, repairDescField.getText());
		            pst.setString(2, repairDateField.getText());
		            pst.setString(3, repairUnitNoField.getText());
		            pst.setString(4, repairNoField.getText()); //(index, String) of "(?,?,?)"
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Edit successful");
		            showRepairsTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		editRepairButton.setBounds(15, 215, 61, 29);
		repairsPane.add(editRepairButton);
		
		JButton removeRepairButton = new JButton("Remove");
		removeRepairButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from repairs where RepairNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, repairNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showRepairsTable();
					
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		removeRepairButton.setBounds(15, 255, 89, 29);
		repairsPane.add(removeRepairButton);
		
		JLabel lblRepairno = new JLabel("RepairNo:");
		lblRepairno.setBounds(15, 179, 71, 20);
		repairsPane.add(lblRepairno);
		
		repairNoField = new JTextField();
		repairNoField.setBounds(121, 176, 152, 26);
		repairsPane.add(repairNoField);
		repairNoField.setColumns(10);
		
		JLabel lblUnitno_1 = new JLabel("UnitNo:");
		lblUnitno_1.setBounds(15, 16, 69, 20);
		repairsPane.add(lblUnitno_1);
		
		JPanel maintenancePane = new JPanel();
		tabbedPane.addTab("Maintenance", null, maintenancePane, null);
		maintenancePane.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(288, 16, 354, 228);
		maintenancePane.add(scrollPane_2);
		
		maintenanceTable = new JTable();
		scrollPane_2.setViewportView(maintenanceTable);
		
		JLabel lblMaintenancedesc = new JLabel("MaintenanceDesc:");
		lblMaintenancedesc.setBounds(15, 50, 126, 20);
		maintenancePane.add(lblMaintenancedesc);
		
		JLabel lblMaintenancedate = new JLabel("MaintenanceDate:");
		lblMaintenancedate.setBounds(15, 86, 126, 20);
		maintenancePane.add(lblMaintenancedate);
		
		maintenanceDescField = new JTextField();
		maintenanceDescField.setBounds(156, 47, 117, 26);
		maintenancePane.add(maintenanceDescField);
		maintenanceDescField.setColumns(10);
		
		maintenanceDateField = new JTextField();
		maintenanceDateField.setText("YYYY-MM-DD");
		maintenanceDateField.setBounds(156, 83, 117, 26);
		maintenancePane.add(maintenanceDateField);
		maintenanceDateField.setColumns(10);
		
		maintenanceUnitNoField = new JTextField();
		maintenanceUnitNoField.setBounds(156, 15, 117, 26);
		maintenancePane.add(maintenanceUnitNoField);
		maintenanceUnitNoField.setColumns(10);
		
		JButton addMaintenanceButton = new JButton("Add");
		addMaintenanceButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String addToDatabase = " insert into maintenance"
		                    +"(MaintenanceDesc, MaintenanceDate, MaintenanceUnitNo)" //tables 
		                    +"values (?,?,?);"; //values
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(addToDatabase);
		            pst.setString(1, maintenanceDescField.getText()); //(index, String) of "(?,?,?)"
		            pst.setString(2, maintenanceDateField.getText());
		            pst.setString(3, maintenanceUnitNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Maintenance registered");
		            showMaintenanceTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		addMaintenanceButton.setBounds(15, 129, 61, 29);
		maintenancePane.add(addMaintenanceButton);
		
		maintenanceNoField = new JTextField();
		maintenanceNoField.setBounds(156, 171, 117, 26);
		maintenancePane.add(maintenanceNoField);
		maintenanceNoField.setColumns(10);
		
		JButton editMaintenanceButton = new JButton("Edit");
		editMaintenanceButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String editFromDatabase = "update maintenance set MaintenanceDesc=?, MaintenanceDate=?, MaintenanceUnitNo=? where MaintenanceNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(editFromDatabase);
		            pst.setString(1, maintenanceDescField.getText());
		            pst.setString(2, maintenanceDateField.getText());
		            pst.setString(3, maintenanceUnitNoField.getText());
		            pst.setString(4, maintenanceNoField.getText()); //(index, String) of "(?,?,?)"
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Edit successful");
		            showMaintenanceTable();
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		editMaintenanceButton.setBounds(15, 210, 61, 29);
		maintenancePane.add(editMaintenanceButton);
		
		JButton removeMaintenanceButton = new JButton("Remove");
		removeMaintenanceButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String removeFromDatabase = "delete from maintenance where MaintenanceNo = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(removeFromDatabase);
		            pst.setString(1, maintenanceNoField.getText());
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Remove successful");
		            showMaintenanceTable();
				}catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		removeMaintenanceButton.setBounds(15, 255, 89, 29);
		maintenancePane.add(removeMaintenanceButton);
		
		JLabel lblMaintenanceno = new JLabel("MaintenanceNo:");
		lblMaintenanceno.setBounds(15, 174, 117, 20);
		maintenancePane.add(lblMaintenanceno);
		
		JLabel lblUnitno = new JLabel("UnitNo:");
		lblUnitno.setBounds(15, 18, 69, 20);
		maintenancePane.add(lblUnitno);
		
			showDamagesTable();
			showRepairsTable();
			showMaintenanceTable();
	}
	
	public void showDamagesTable() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from damages";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        damagesTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public void showRepairsTable() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from repairs";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        repairsTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public void showMaintenanceTable() {
		try {
			conn = DriverManager.getConnection(dbsURL, userName, password);
			String select = "select * from maintenance";
			pst = conn.prepareStatement(select);
			rs = pst.executeQuery();
	        maintenanceTable.setModel(DbUtils.resultSetToTableModel(rs));
		}catch(SQLException e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
}
