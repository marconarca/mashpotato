import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class EditDriverFrame extends JFrame {

	private JPanel contentPane;
	private JTextField fNameField;
	private JTextField mNameField;
	private JTextField lNameField;
	private JTextField addressField;
	private JTextField bDateField;
	private JTextField contactNumberField;
	
    private String dbsURL = "jdbc:mysql://localhost/finals";
    private String userName = "root";
    private String password = "Iammartin..64Mykee20180014301";
    private Connection conn = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    
	/**
	 * Create the frame.
	 */
	public EditDriverFrame(String driverID) {
		setVisible(true);
		setTitle("AVMS: Edit driver");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 638, 386);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(15, 16, 588, 301);
		contentPane.add(panel);
		
		JLabel label = new JLabel("First name:");
		label.setBounds(64, 16, 80, 20);
		panel.add(label);
		
		JLabel label_1 = new JLabel("Middle name:");
		label_1.setBounds(48, 52, 96, 20);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Last name:");
		label_2.setBounds(66, 88, 78, 20);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Birthdate:");
		label_3.setBounds(70, 124, 74, 20);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("Address:");
		label_4.setBounds(76, 160, 68, 20);
		panel.add(label_4);
		
		JLabel label_5 = new JLabel("Contact number:");
		label_5.setBounds(25, 196, 119, 20);
		panel.add(label_5);
		
		fNameField = new JTextField();
		fNameField.setColumns(10);
		fNameField.setBounds(157, 13, 343, 26);
		panel.add(fNameField);
		
		mNameField = new JTextField();
		mNameField.setColumns(10);
		mNameField.setBounds(157, 49, 343, 26);
		panel.add(mNameField);
		
		lNameField = new JTextField();
		lNameField.setColumns(10);
		lNameField.setBounds(157, 85, 343, 26);
		panel.add(lNameField);
		
		addressField = new JTextField();
		addressField.setColumns(10);
		addressField.setBounds(157, 157, 343, 26);
		panel.add(addressField);
		
		bDateField = new JTextField();
		bDateField.setText("YYYY-MM-DD");
		bDateField.setColumns(10);
		bDateField.setBounds(157, 121, 343, 26);
		panel.add(bDateField);
		
		contactNumberField = new JTextField();
		contactNumberField.setColumns(10);
		contactNumberField.setBounds(159, 193, 343, 26);
		panel.add(contactNumberField);
		
		JButton saveChangesButton = new JButton("Save changes");
		saveChangesButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try{
		            String editFromDatabase = "update drivers set Fname=?, Lname=?, Mname=?, Bdate=?, Address=?, ContactNumber=? where DriverID = ?";
		            conn = DriverManager.getConnection(dbsURL, userName, password);
		            pst = conn.prepareStatement(editFromDatabase);
		            pst.setString(1, fNameField.getText());
		            pst.setString(2, mNameField.getText());
		            pst.setString(3, lNameField.getText());
		            pst.setString(4, bDateField.getText());
		            pst.setString(5, addressField.getText());
		            pst.setString(6, contactNumberField.getText());
		            pst.setString(7, driverID);
		            pst.executeUpdate();
		            JOptionPane.showMessageDialog(null, "Edit successful");
		        }catch(HeadlessException | SQLException ex){
		            JOptionPane.showMessageDialog(null, ex);
		        }
			}
		});
		saveChangesButton.setBounds(446, 256, 127, 29);
		panel.add(saveChangesButton);
	}
}
